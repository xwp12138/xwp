from data import data_read,data_process
from optimize import outer_function,model_optimize
from save import save_hyperparameter,save_result
from model_config import MyModelConfig,model_list,dl_model_list,ml_model_list,my_model_list
from model_build import ModelBuild,ml_model_bulid,ml_model_pred
from mymodel import mymodel_implement

import statistics
import logging
logging.getLogger("pytorch_lightning").setLevel(logging.WARNING)

if __name__ == "__main__":
    #加载数据
    dataset_dict, target_col, num_col_names, categorical_cols = data_read('../dataset_csv')
    data_process(dataset_dict)

    dataset_list = list(dataset_dict.keys())
    metric_list = ['mse','mae','rmse','r2']
    #创建len(model_list)行，len(dataset_list)*len(metric_list)列的二维空列表
    result = [[] for j in range(len(model_list))]
    for model in model_list:
        print('当前Model : ',model)
        #模型优化
        print('optimizing...')
        train = dataset_dict[list(dataset_dict.keys())[0]]['train'][0]
        valid = dataset_dict[list(dataset_dict.keys())[0]]['valid'][0]
        test = dataset_dict[list(dataset_dict.keys())[0]]['test'][0]
        scaler = dataset_dict[list(dataset_dict.keys())[0]]['scale'][0]
        objective = outer_function(target_col, num_col_names, categorical_cols, model, train, valid, test, scaler)
        optimize_param = model_optimize(objective,n_trials=1)

        #保存优化后参数
        save_hyperparameter(model,optimize_param)

        #对比模型性能
        for dataset in dataset_dict.keys():

            print('当前数据集 : ',dataset)
            test_mse_list = []
            test_mae_list = []
            test_rmse_list = []
            test_r2_list = []

            for i in range(len(dataset_dict[dataset]['train'])):
                train = dataset_dict[dataset]['train'][i]
                valid = dataset_dict[dataset]['valid'][i]
                test = dataset_dict[dataset]['test'][i]
                scaler = dataset_dict[dataset]['scale'][i]

                if model in dl_model_list:
                    config = MyModelConfig(**optimize_param)
                    model_config = config.model_config(model_name=model)
                    mymodel = ModelBuild(target_col, num_col_names, categorical_cols, model_config)
                    test_mse,test_mae,test_rmse,test_r2=mymodel.pred(train, valid, test, scaler, mode='test')
                elif model in ml_model_list:
                    mymodel = ml_model_bulid(model,optimize_param)
                    test_mse,test_mae,test_rmse,test_r2=ml_model_pred(mymodel, train, valid, test, scaler, mode='test')
                elif model in my_model_list:
                    mymodel = mymodel_implement(model,optimize_param)
                    test_mse,test_mae,test_rmse,test_r2=mymodel.pred(train, valid, test, scaler, mode='test')
                test_mse_list.append(test_mse)
                test_mae_list.append(test_mae)
                test_rmse_list.append(test_rmse)
                test_r2_list.append(test_r2)

            #输出均值±标准差
            mean_mse = statistics.mean(test_mse_list)
            std_mse = statistics.stdev(test_mse_list)
            mean_mae = statistics.mean(test_mae_list)
            std_mae = statistics.stdev(test_mae_list)
            mean_rmse = statistics.mean(test_rmse_list)
            std_rmse = statistics.stdev(test_rmse_list)
            mean_r2 = statistics.mean(test_r2_list)
            std_r2 = statistics.stdev(test_r2_list)

            print('MSE {}±{}: '.format(mean_mse,std_mse))
            print('MAE {}±{}: '.format(mean_mae,std_mae))
            print('RMSE {}±{}: '.format(mean_rmse,std_rmse))
            print('R2 {}±{}: '.format(mean_r2,std_r2))

            result[model_list.index(model)].append(f"{mean_mse:.3f}±{std_mse:.3f}")
            result[model_list.index(model)].append(f"{mean_mae:.3f}±{std_mae:.3f}")
            result[model_list.index(model)].append(f"{mean_rmse:.3f}±{std_rmse:.3f}")
            result[model_list.index(model)].append(f"{mean_r2:.3f}±{std_r2:.3f}")

    save_result(dataset_list, metric_list, model_list, result)













