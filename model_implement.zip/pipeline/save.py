import pandas as pd
#在hyperparameter目录下创建csv文件，文件名为model，内容为模型的超参数字典
def save_hyperparameter(model, hyperparameters):
    #判断hyperparameters是否为字典
    if not isinstance(hyperparameters, pd.DataFrame):
        df = pd.DataFrame([hyperparameters])
    elif hyperparameters == None:
        return
    else:
        df = hyperparameters
    df.to_csv(f'hyperparameter/{model}.csv',index=False)

def save_result(dataset_list,metric_list,model_list, data):
    columns = pd.MultiIndex.from_product(
        [dataset_list, metric_list],
        names=['dataset', 'metric']
    )

    # # 假设以下是你的测试结果
    # data = [
    #     ['0±1', 0.2, 0.3, 0.8, 0.1, 0.2, 0.3, 0.8, 0.1, 0.2, 0.3, 0.8, 0.1, 0.2, 0.3, 0.8],
    #     [0.2, 0.3, 0.4, 0.7, 0.2, 0.3, 0.4, 0.7, 0.2, 0.3, 0.4, 0.7, 0.2, 0.3, 0.4, 0.7],
    #     [0.3, 0.4, 0.5, 0.6, 0.3, 0.4, 0.5, 0.6, 0.3, 0.4, 0.5, 0.6, 0.3, 0.4, 0.5, 0.6]
    # ]

    # 行索引
    index = model_list

    # 创建 DataFrame
    df = pd.DataFrame(data, index=index, columns=columns)

    # 保存为xlsx
    df.to_excel('result.xlsx')



if __name__ == "__main__":
    save_result(None, None, None, None)
    pass