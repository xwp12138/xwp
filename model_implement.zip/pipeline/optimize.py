import optuna
from model_config import MyModelConfig,dl_model_list, ml_model_list, my_model_list
from model_build import ModelBuild,ml_model_bulid,ml_model_pred
from optimize_search_space import search_space_selection
from mymodel import mymodel_implement

def outer_function(target_col, num_col_names,
                   cat_col_names, model_name,
                   train, valid, test, scaler):
    def objective(trial):
        param = search_space_selection(trial,model_name)
        if model_name in dl_model_list:
            config = MyModelConfig(**param)
            model_config = config.model_config(model_name=model_name)
            model = ModelBuild(target_col, num_col_names, cat_col_names, model_config,batch_size=param['batch_size'])
            return model.pred(train, valid, test, scaler, mode='optimize')

        elif model_name in ml_model_list:
            model = ml_model_bulid(model_name,param)
            return ml_model_pred(model, train, valid, test, scaler, mode='optimize')

        elif model_name in my_model_list:
            model = mymodel_implement(model_name,param)
            return model.pred(train, valid, test, scaler, mode='optimize')


    return objective

def model_optimize(objective,n_trials):
    study = optuna.create_study(direction='minimize')
    study.optimize(objective,n_trials=n_trials)
    trial = study.best_trial
    print('  Best hyperparameters: ', trial.params)
    return trial.params
