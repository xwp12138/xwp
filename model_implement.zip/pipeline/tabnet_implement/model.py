import numpy as np
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from pytorch_tabnet.tab_model import TabNetRegressor
from utils import hiddenPrint
import warnings
warnings.filterwarnings("ignore", message="Device used : cuda")

class MyModelTabNet(object):
    def __init__(self,batch_size=32,max_epochs=150):
        self.model = TabNetRegressor()
        self.batch_size = batch_size
        self.max_epochs = max_epochs
    def pred(self,train,valid,test,scaler,mode='optimize'):
        train_x = train.iloc[:,:-1].values
        train_y = train.iloc[:,-1].values.reshape(-1,1)
        valid_x = valid.iloc[:,:-1].values
        valid_y = valid.iloc[:,-1].values.reshape(-1,1)
        test_x = test.iloc[:,:-1].values
        test_y = test.iloc[:,-1].values.reshape(-1,1)
        with hiddenPrint():
            self.model.fit(
                train_x, train_y,
                eval_set=[(valid_x, valid_y)],
                eval_name=['valid'],
                eval_metric=['rmse'],
                max_epochs=self.max_epochs,
                patience=500,
                batch_size=self.batch_size,
                virtual_batch_size=self.batch_size,  # 128
                num_workers=0,
                drop_last=False,
            )
        pred_test = self.model.predict(test_x)
        pred_val = self.model.predict(valid_x)

        y_val_actual = scaler.inverse_transform(valid_y).flatten()
        y_val_pred_actual = scaler.inverse_transform(pred_val).flatten()

        y_test_actual = scaler.inverse_transform(test_y).flatten()
        y_test_pred_actual = scaler.inverse_transform(pred_test).flatten()

        # 分别计算指标
        val_mse = mean_squared_error(y_val_actual, y_val_pred_actual)
        val_mae = mean_absolute_error(y_val_actual, y_val_pred_actual)
        val_rmse = np.sqrt(val_mse)
        val_r2 = r2_score(y_val_actual, y_val_pred_actual)

        test_mse = mean_squared_error(y_test_actual, y_test_pred_actual)
        test_mae = mean_absolute_error(y_test_actual, y_test_pred_actual)
        test_rmse = np.sqrt(test_mse)
        test_r2 = r2_score(y_test_actual, y_test_pred_actual)

        if mode == 'optimize':
            return val_rmse
        else:
            return test_mse, test_mae, test_rmse, test_r2





