import sys
import os
import contextlib

@contextlib.contextmanager
def hiddenPrint():
    try:
        original_stdout = sys.stdout
        original_stderr = sys.stderr
        sys.stdout = open(os.devnull,'w', encoding='utf-8')
        sys.stderr = open(os.devnull,'w', encoding='utf-8')
        yield
    # 用这个来指示打印
    except Exception as e:
        sys.stdout.close()
        sys.stdout = original_stdout
        print(e.args[0])
        sys.stdout = open(os.devnull, 'w')
    finally:
        sys.stdout.close()
        sys.stderr.close()
        sys.stdout = original_stdout
        sys.stderr = original_stderr