import os
import pandas as pd
from sklearn.preprocessing import StandardScaler
def data_read(root_path):
    dataset_dict = {}
    dataset_list = os.listdir(root_path)
    for dataset in dataset_list:
        dataset_dict[dataset] = {}
        file_list = os.listdir(os.path.join(root_path, dataset))
        dataset_dict[dataset]['train']=[]
        dataset_dict[dataset]['test']=[]
        dataset_dict[dataset]['valid']=[]
        dataset_dict[dataset]['scale'] = []
        for file in file_list:
            temp = os.path.join(root_path, dataset, file)
            temp_pd = pd.read_csv(temp)
            if 'train' in file:
                dataset_dict[dataset]['train'].append(temp_pd)
            elif 'test' in file:
                dataset_dict[dataset]['test'].append(temp_pd)
            elif 'valid' in file:
                dataset_dict[dataset]['valid'].append(temp_pd)

        target_col = temp_pd.columns[-1]
        num_col_names = list(temp_pd.columns[:-1])
        categorical_cols = []
    return dataset_dict, target_col, num_col_names, categorical_cols

def data_process(dataset_dict):
    #遍历dataset_dict的键
    for dataset in dataset_dict.keys():

        for i in range(len(dataset_dict[dataset]['train'])):

            scaler_x = StandardScaler()
            scaler_y = StandardScaler()

            train_x = dataset_dict[dataset]['train'][i].iloc[:,:-1]
            valid_x = dataset_dict[dataset]['valid'][i].iloc[:,:-1]
            test_x = dataset_dict[dataset]['test'][i].iloc[:,:-1]

            train_y = dataset_dict[dataset]['train'][i].iloc[:,-1].values.reshape(-1,1)
            valid_y = (dataset_dict[dataset]['valid'][i].iloc[:, -1]).values.reshape(-1,1)
            test_y = dataset_dict[dataset]['test'][i].iloc[:,-1].values.reshape(-1,1)

            #对x进行标准化
            train_x_scaled = scaler_x.fit_transform(train_x)
            valid_x_scaled = scaler_x.transform(valid_x)
            test_x_scaled = scaler_x.transform(test_x)

            #对y进行标准化
            train_y_scaled = scaler_y.fit_transform(train_y)
            valid_y_scaled = scaler_y.transform(valid_y)
            test_y_scaled = scaler_y.transform(test_y)

            #合并xy
            train_scaled = pd.concat([pd.DataFrame(train_x_scaled, columns=train_x.columns), pd.DataFrame(train_y_scaled, columns=[dataset_dict[dataset]['train'][i].columns[-1]])], axis=1)
            valid_scaled = pd.concat([pd.DataFrame(valid_x_scaled, columns=valid_x.columns), pd.DataFrame(valid_y_scaled, columns=[dataset_dict[dataset]['valid'][i].columns[-1]])], axis=1)
            test_scaled = pd.concat([pd.DataFrame(test_x_scaled, columns=test_x.columns), pd.DataFrame(test_y_scaled, columns=[dataset_dict[dataset]['test'][i].columns[-1]])], axis=1)

            dataset_dict[dataset]['train'][i] = train_scaled
            dataset_dict[dataset]['valid'][i] = valid_scaled
            dataset_dict[dataset]['test'][i] = test_scaled

            dataset_dict[dataset]['scale'].append(scaler_y)

    return dataset_dict


if __name__ == "__main__":
    dataset_dict,_,_,_ = data_read('../dataset_csv')
    data_process(dataset_dict)