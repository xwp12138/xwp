from tabnet_implement.model import MyModelTabNet
from ftt_implement.model import MyModelFTT
from ftt_implement.model_2 import MyModelFTT2
from mlp_implement.model import MyModelMLP
from resnet_implement.model import MyModelResNet
def mymodel_implement(model_name,param):
    if model_name == 'tabnet1':
        return MyModelTabNet()
    elif model_name == 'ftt1':
        return MyModelFTT()
    elif model_name == 'ftt2':
        return MyModelFTT2()
    elif model_name == 'mlp':
        return MyModelMLP()
    elif model_name == 'resnet':
        return MyModelResNet()
