from pytorch_tabular.models import (
    CategoryEmbeddingModelConfig,
    NodeConfig,
    TabNetModelConfig,
    MDNConfig,
    AutoIntConfig,
    TabTransformerConfig,
    FTTransformerConfig,
    GatedAdditiveTreeEnsembleConfig,
    GANDALFConfig,
    DANetConfig,
)
from pytorch_tabular.models.common.heads import LinearHeadConfig,MixtureDensityHeadConfig
class MyModelConfig(object):
    def __init__(self,lr=1e-3,task='regression',
        ff_hidden_multiplier=5,num_attn_blocks=3,#ftt
        batch_size=64, #no use
                 ):
        head_config = LinearHeadConfig(
            layers="",  # No additional layer in head, just a mapping layer to output_dim
            dropout=0.1,
            initialization="kaiming",
        ).__dict__  # Convert to dict to pass to the model config (OmegaConf doesn't accept objects)

        mdnheadconfig = MixtureDensityHeadConfig().__dict__

        mdn_ftt_backbone_config = FTTransformerConfig(
            task=task,
            head_config=head_config,
            learning_rate=lr,
        ).__dict__
        self.categoryembeddingmodelconfig = CategoryEmbeddingModelConfig(
            task=task,
            layers="1024-512-512",  # Number of nodes in each layer
            activation="LeakyReLU",  # Activation between each layers
            learning_rate=lr,  # Learning Rate
            head_config=head_config,  # Linear Head Config
        )
        self.nodeconfig = NodeConfig(
            task=task,
            num_trees=256,
            depth=6,
            head_config=head_config,
            learning_rate=lr,
        )
        # self.tabnetmodelconfig = TabNetModelConfig(
        #     task=task,
        #     head_config=head_config,
        #     learning_rate=lr,
        # )
        self.tabnetmodelconfig = TabNetModelConfig(
            task=task,
            learning_rate=lr,
            n_d=16,
            n_a=16,
            n_steps=4,
            head="LinearHead",  # Linear Head
            head_config=head_config,  # Linear Head Config
        )

        self.mdnconfig = MDNConfig(
            backbone_config_class='FTTransformerConfig',
            backbone_config_params=mdn_ftt_backbone_config,
            task=task,
            head_config=mdnheadconfig,
            learning_rate=lr,
        )
        self.autointconfig = AutoIntConfig(
            task=task,
            head_config=head_config,
            learning_rate=lr,
        )
        self.tabtransformerconfig = TabTransformerConfig(
            task=task,
            head_config=head_config,
            learning_rate=lr,
        )
        self.fttransformerconfig = FTTransformerConfig(
            task=task,
            ff_hidden_multiplier=ff_hidden_multiplier,
            num_attn_blocks=num_attn_blocks,
            head_config=head_config,
            learning_rate=lr,
        )
        self.gatedadditivetreeensembleconfig = GatedAdditiveTreeEnsembleConfig(
            task=task,
            head_config=head_config,
            learning_rate=lr,
        )
        self.gandalfconfig = GANDALFConfig(
            task=task,
            head_config=head_config,
            learning_rate=lr,
        )
        self.danetconfig = DANetConfig(
            task=task,
            head_config=head_config,
            learning_rate=lr,
        )
    def model_config(self,model_name):
        if model_name == 'CategoryEmbeddingModel':
            return self.categoryembeddingmodelconfig
        elif model_name == 'Node':
            return self.nodeconfig
        elif model_name == 'TabNetModel':
            return self.tabnetmodelconfig
        elif model_name == 'MDN':
            return self.mdnconfig
        elif model_name == 'AutoInt':
            return self.autointconfig
        elif model_name == 'TabTransformer':
            return self.tabtransformerconfig
        elif model_name == 'FTTransformer':
            return self.fttransformerconfig
        elif model_name == 'GatedAdditiveTreeEnsemble':
            return self.gatedadditivetreeensembleconfig
        elif model_name == 'GANDALF':
            return self.gandalfconfig
        elif model_name == 'DANet':
            return self.danetconfig
        else:
            return self.fttransformerconfig
dl_model_list = ['CategoryEmbeddingModel','Node','TabNetModel','MDN','AutoInt','TabTransformer','FTTransformer','GatedAdditiveTreeEnsemble','GANDALF','DANet']
ml_model_list =[
    'LGBM',  # LightGBM
    'XGB',   # XGBoost
    'RF',    # Random Forest
    'CAT',   # CatBoost
    'LR',    # Linear Regression
    'KNN',   # K-Nearest Neighbors
    'GPR',   # Gaussian Process Regressor
    'PLS',   # PLS Regression
    'ADAB',  # AdaBoost
    'GBDT',  # Gradient Boosting Decision Trees
    'ET',    # Extra Trees
    'SVR',   # Support Vector Regression
    'EN'     # ElasticNet
]
my_model_list = ['ftt1','ftt2','tabnet1','mlp','resnet']
#拼接
model_list = ml_model_list + dl_model_list + my_model_list
model_list = ['mlp','resnet']