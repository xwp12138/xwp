def search_space_selection(trial,model):
    if model == 'LGBM':
        param = {
            'num_leaves': trial.suggest_categorical('num_leaves',[20, 30, 40, 50]),
            'learning_rate': trial.suggest_categorical('learning_rate', [0.02, 0.05, 0.1, 0.15]),
            'n_estimators': trial.suggest_categorical('n_estimators', [350, 600, 1200, 2000]),
            'max_depth': trial.suggest_categorical('max_depth', [15, 30, 45])
        }
    elif model == 'XGB':
        param = {
            'max_depth': trial.suggest_int('max_depth', 5, 9),
            'learning_rate': trial.suggest_categorical('learning_rate', [0.01, 0.03, 0.05, 0.07, 0.09, 0.1, 0.12, 0.15]),
            'n_estimators': trial.suggest_categorical('n_estimators', [1000, 2000, 3000, 5000, 7000]),
            'objective': 'reg:squarederror',
        }
    elif model == 'RF':
        param = {
            'n_estimators': trial.suggest_categorical('n_estimators', [3000, 4000, 5000, 6000, 7000]),
            'max_depth': trial.suggest_categorical('max_depth', [20, 25, 30, 35, 40]),
        }
    elif model == 'CAT':
        param = {
            'max_depth': trial.suggest_int('depth', 5, 9),
            'learning_rate': trial.suggest_categorical('learning_rate',[0.01, 0.03, 0.05, 0.07, 0.09, 0.1, 0.12, 0.15]),
            'n_estimators': trial.suggest_categorical('iterations', [400, 500, 600, 700, 800, 900, 1000]),
            'loss_function': 'RMSE',
        }
    elif model == 'FTTransformer':
        param = {
            #令lr从5e-3到5e-5
            # 'lr' : trial.suggest_categorical('lr',[5e-5,1e-4,2e-4,5e-4,1e-3,2e-3,5e-3]),
            'lr': trial.suggest_float('lr', 5e-5, 5e-3, log=True),
            # 'ff_hidden_multiplier': trial.suggest_int('ff_hidden_multiplier', 2, 5),
            # 'num_attn_blocks': trial.suggest_int('num_attn_blocks', 2, 6),
            'batch_size': trial.suggest_categorical('batch_size', [24, 32, 48, 64, 96, 128, 192, 256]),
        }
    elif model == 'LR':
        param = None
    elif model == 'KNN':
        param = None
    elif model == 'GPR':
        param = None
    elif model == 'PLS':
        param = None
    elif model == 'ADAB':
        param = None
    elif model == 'GBDT':
        param = None
    elif model == 'ET':
        param = None
    elif model == 'SVR':
        param = None
    elif model == 'EN':
        param = None
    elif model == 'ftt1':
        param = None
    elif model == 'ftt2':
        param = None
    elif model == 'tabnet1':
        param = None
    elif model == 'mlp':
        param = None
    elif model == 'resnet':
        param = None
    else :
        param = {
            #令lr从5e-3到5e-5
            'lr' : trial.suggest_float('lr', 5e-5, 5e-3, log=True)
        }
    return param

