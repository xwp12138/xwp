from pytorch_tabular import TabularModel
from pytorch_tabular.config import (
    DataConfig,
    OptimizerConfig,
    TrainerConfig,
)
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import numpy as np


from utils import hiddenPrint
from sklearn.neighbors import KNeighborsRegressor
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.cross_decomposition import PLSRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.ensemble import AdaBoostRegressor
from sklearn import linear_model
from sklearn import svm
from sklearn.ensemble import GradientBoostingRegressor
from  sklearn.tree import ExtraTreeRegressor
from xgboost import XGBRegressor
from catboost import CatBoostRegressor
import lightgbm as lgb




class ModelBuild(object):
    def __init__(self, target_col, num_col_names, cat_col_names,model_config,
                 batch_size=64, max_epochs=50):
        data_config = DataConfig(
            target=[target_col],
            continuous_cols=num_col_names,
            categorical_cols=cat_col_names,
        )

        trainer_config = TrainerConfig(
            auto_lr_find=False,  # Runs the LRFinder to automatically derive a learning rate
            batch_size=batch_size,
            max_epochs=max_epochs,
            early_stopping="valid_loss",  # Monitor valid_loss for early stopping
            early_stopping_mode="min",  # Set the mode as min because for val_loss, lower is better
            early_stopping_patience=50,  # No. of epochs of degradation training will wait before terminating
            checkpoints="valid_loss",  # Save best checkpoint monitoring val_loss
            load_best=True,  # After training, load the best checkpoint
        )

        optimizer_config = OptimizerConfig()

        self.model = TabularModel(
            data_config=data_config,
            model_config=model_config,
            optimizer_config=optimizer_config,
            trainer_config=trainer_config,
            verbose=False,
        )
    def pred(self,train,valid,test,scaler,mode='optimize'):
        with hiddenPrint():
            self.model.fit(train=train, validation=valid)

        pred_val = self.model.predict(valid)
        pred_test = self.model.predict(test)

        y_val_actual = scaler.inverse_transform(valid['BTH'].values.reshape(-1, 1)).flatten()
        y_val_pred_actual = scaler.inverse_transform(pred_val['BTH_prediction'].values.reshape(-1, 1)).flatten()

        y_test_actual = scaler.inverse_transform(test['BTH'].values.reshape(-1, 1)).flatten()
        y_test_pred_actual = scaler.inverse_transform(pred_test['BTH_prediction'].values.reshape(-1, 1)).flatten()

        #分别计算指标
        val_mse = mean_squared_error(y_val_actual, y_val_pred_actual)
        val_mae = mean_absolute_error(y_val_actual, y_val_pred_actual)
        val_rmse = np.sqrt(val_mse)
        val_r2 = r2_score(y_val_actual, y_val_pred_actual)

        test_mse = mean_squared_error(y_test_actual, y_test_pred_actual)
        test_mae = mean_absolute_error(y_test_actual, y_test_pred_actual)
        test_rmse = np.sqrt(test_mse)
        test_r2 = r2_score(y_test_actual, y_test_pred_actual)

        if mode == 'optimize':
            return val_rmse
        else:
            return test_mse,test_mae,test_rmse,test_r2

def ml_model_bulid(model_name,param_dict):
    if model_name == 'LR':
        model = linear_model.LinearRegression()
    elif model_name == 'KNN':
        model = KNeighborsRegressor()
    elif model_name == 'GPR':
        model = GaussianProcessRegressor()
    elif model_name == 'PLS':
        model = PLSRegression()
    elif model_name == 'RF':
        model = RandomForestRegressor(**param_dict)
    elif model_name == 'ADAB':
        model = AdaBoostRegressor()
    elif model_name == 'SVR':
        model = svm.SVR()
    elif model_name == 'GBDT':
        model = GradientBoostingRegressor()
    elif model_name == 'ET':
        model = ExtraTreeRegressor()
    elif model_name == 'XGB':
        model = XGBRegressor(**param_dict)
    elif model_name == 'CAT':
        model = CatBoostRegressor(**param_dict, verbose=0)
    elif model_name == 'LGBM':
        model = lgb.LGBMRegressor(**param_dict)
    elif model_name == 'EN':
        model = linear_model.ElasticNet()

    return model
def ml_model_pred(model,train,valid,test,scaler,mode='optimize'):
    with hiddenPrint():
        model.fit(train.iloc[:, :-1], train.iloc[:, -1])

    pred_val = model.predict(valid.iloc[:, :-1])
    pred_test = model.predict(test.iloc[:, :-1])

    y_val_actual = scaler.inverse_transform(valid.iloc[:, -1].values.reshape(-1, 1)).flatten()
    y_val_pred_actual = scaler.inverse_transform(pred_val.reshape(-1, 1)).flatten()

    y_test_actual = scaler.inverse_transform(test.iloc[:, -1].values.reshape(-1, 1)).flatten()
    y_test_pred_actual = scaler.inverse_transform(pred_test.reshape(-1, 1)).flatten()

    #分别计算指标
    val_mse = mean_squared_error(y_val_actual, y_val_pred_actual)
    val_mae = mean_absolute_error(y_val_actual, y_val_pred_actual)
    val_rmse = np.sqrt(val_mse)
    val_r2 = r2_score(y_val_actual, y_val_pred_actual)

    test_mse = mean_squared_error(y_test_actual, y_test_pred_actual)
    test_mae = mean_absolute_error(y_test_actual, y_test_pred_actual)
    test_rmse = np.sqrt(test_mse)
    test_r2 = r2_score(y_test_actual, y_test_pred_actual)

    if mode == 'optimize':
        return val_rmse
    else:
        return test_mse,test_mae,test_rmse,test_r2