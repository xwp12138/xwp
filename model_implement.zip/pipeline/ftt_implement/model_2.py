import os
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import Dataset
from utils import hiddenPrint
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from rtdl_revisiting_models import FTTransformer

class TabularDataset(Dataset):
    def __init__(self, X, Y):
        super(TabularDataset,self).__init__()
        self.X = torch.tensor(X, dtype=torch.float32)
        self.Y = torch.tensor(Y, dtype=torch.float32)
    def __len__(self):
        return len(self.X)
    def __getitem__(self, idx):
        return self.X[idx],self.Y[idx]

def evaluate_metrix(y_pred, y_test):
    from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_percentage_error
    rmse = mean_squared_error(y_test.cpu(), y_pred.cpu(), squared=False)
    mse = mean_squared_error(y_test.cpu(), y_pred.cpu())
    r2 = r2_score(y_test.cpu(), y_pred.cpu())
    mape = mean_absolute_percentage_error(y_test.cpu(), y_pred.cpu())
    return rmse, mse, r2, mape

class MyModelFTT2(object):
    def __init__(self,d_numerical = 81,batch_size=32,learning_rate=1e-4,epochs=150):
        self.device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        self.batch_size = batch_size
        self.learning_rate = learning_rate
        self.epochs = epochs
        self.model_path=os.getcwd()+r'\ftt_implement\model_ftt.pth'

        self.model = FTTransformer(
            n_cont_features=d_numerical,
            cat_cardinalities=None,  # 无分类特征
            d_out=1,
            n_blocks=4,
            d_block=256,
            attention_n_heads=8,  # 注意力头数量
            attention_dropout=0.1,
            ffn_d_hidden=None,
            ffn_d_hidden_multiplier=4 / 3,
            ffn_dropout=0.2,  # 0.05
            residual_dropout=0.0,
        ).to(self.device)

    def dataset_utils(self,ds,shuffle=True):
        from torch.utils.data import DataLoader
        #传入的train为pandas格式，取除最后一列为Y，其余为X
        ds_x = ds.iloc[:,:-1].values
        ds_y = ds.iloc[:,-1].values.reshape(-1,1)

        ds = TabularDataset(ds_x, ds_y)
        dataloader = DataLoader(ds, batch_size=self.batch_size, shuffle=shuffle, num_workers=0, drop_last=False)

        return dataloader

    def optimizer_utils(self):
        criterion = nn.MSELoss().to(self.device)
        optimizer = torch.optim.AdamW(self.model.parameters(), lr=self.learning_rate)
        scheduler = torch.optim.lr_scheduler.ExponentialLR(optimizer, gamma=0.98)
        return criterion,optimizer,scheduler

    def fit(self,train,validation):
        train_dataloader = self.dataset_utils(train)
        valid_dataloader = self.dataset_utils(validation,shuffle=False)
        criterion,optimizer,scheduler = self.optimizer_utils()
        R2_MAX = -1000

        for epoch in range(self.epochs):
            # train
            self.model.train()
            running_loss = 0.0
            for _, data in enumerate(train_dataloader):
                optimizer.zero_grad()
                X, Y = data[0].to(self.device), data[1].to(self.device)
                Y_pred = self.model(x_cont=X, x_cat=None)
                loss = criterion(Y_pred, Y)
                loss.backward()
                optimizer.step()
                running_loss += loss.item()
            scheduler.step()
            print('训练第 %d 轮 训练损失: %.4f' % (epoch, running_loss))

            # valid
            self.model.eval()
            y_pred_list = []
            y_test_list = []
            with torch.no_grad():
                for _, data in enumerate(valid_dataloader):
                    X, Y = data[0].to(self.device), data[1].to(self.device)
                    Y_pred = self.model(x_cont=X, x_cat=None)
                    y_pred_list.append(Y_pred)
                    y_test_list.append(Y)
                y_pred = torch.cat(y_pred_list, dim=0)
                y_test = torch.cat(y_test_list, dim=0)
                rmse, mse, r2, mape = evaluate_metrix(y_pred, y_test)
                print('验证第 %d 轮 RMSE: %.4f R2: %.4f' % (epoch, rmse, r2))
                if r2 > R2_MAX:
                    torch.save(self.model.state_dict(), self.model_path)
                    R2_MAX = r2
        self.model.load_state_dict(torch.load(self.model_path,weights_only=False))

    def predict(self,ds):
        dataloader = self.dataset_utils(ds,shuffle=False)
        self.model.load_state_dict(torch.load(self.model_path,weights_only=False))
        self.model.eval()
        y_pred_list = []

        with torch.no_grad():
            for _, data in enumerate(dataloader):
                X, Y = data[0].to(self.device), data[1].to(self.device)
                Y_pred = self.model(x_cont=X, x_cat=None)
                y_pred_list.append(Y_pred)

            y_pred = torch.cat(y_pred_list, dim=0).cpu().numpy()
        return y_pred

    def pred(self,train,valid,test,scaler,mode='optimize'):
        with hiddenPrint():
            self.fit(train=train, validation=valid)

        pred_val = self.predict(valid)
        pred_test = self.predict(test)

        y_val_actual = scaler.inverse_transform(valid.iloc[:,-1].values.reshape(-1, 1)).flatten()
        y_val_pred_actual = scaler.inverse_transform(pred_val).flatten()

        y_test_actual = scaler.inverse_transform(test.iloc[:,-1].values.reshape(-1, 1)).flatten()
        y_test_pred_actual = scaler.inverse_transform(pred_test).flatten()

        # 分别计算指标
        val_mse = mean_squared_error(y_val_actual, y_val_pred_actual)
        val_mae = mean_absolute_error(y_val_actual, y_val_pred_actual)
        val_rmse = np.sqrt(val_mse)
        val_r2 = r2_score(y_val_actual, y_val_pred_actual)

        test_mse = mean_squared_error(y_test_actual, y_test_pred_actual)
        test_mae = mean_absolute_error(y_test_actual, y_test_pred_actual)
        test_rmse = np.sqrt(test_mse)
        test_r2 = r2_score(y_test_actual, y_test_pred_actual)

        if mode == 'optimize':
            return val_rmse
        else:
            return test_mse, test_mae, test_rmse, test_r2



