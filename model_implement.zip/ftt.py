"""Reported (reproduced) results of FT-Transformer
https://arxiv.org/abs/2106.11959.

adult 85.9 (85.5)
helena 39.1 (39.2)
jannis 73.2 (72.2)
california_housing 0.459 (0.537)
--------
Reported (reproduced) results of ResNet
https://arxiv.org/abs/2106.11959

adult 85.7 (85.4)
helena 39.6 (39.1)
jannis 72.8 (72.5)
california_housing 0.486 (0.523)
"""
import argparse
import os.path as osp

import torch
import torch.nn.functional as F
from tqdm import tqdm

from torch_frame import stype
from torch_frame.data import DataLoader
from torch_frame.datasets import Yandex
from utils.dataset_prepare import CustomDataset
from torch_frame.nn import (
    EmbeddingEncoder,
    FTTransformer,
    LinearBucketEncoder,
    LinearEncoder,
    LinearPeriodicEncoder,
    ResNet,
)

parser = argparse.ArgumentParser()
parser.add_argument('--dataset', type=str, default='adult')
parser.add_argument('--numerical_encoder_type', type=str, default='linear',
                    choices=['linear', 'linearbucket', 'linearperiodic'])
parser.add_argument('--model_type', type=str, default='fttransformer',
                    choices=['fttransformer', 'resnet'])
parser.add_argument('--channels', type=int, default=256)
parser.add_argument('--num_layers', type=int, default=4)
parser.add_argument('--batch_size', type=int, default=128)
parser.add_argument('--lr', type=float, default=0.001)
parser.add_argument('--epochs', type=int, default=50)
parser.add_argument('--seed', type=int, default=0)
parser.add_argument('--compile', action='store_true',default=False)
args = parser.parse_args()

torch.manual_seed(args.seed)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# Prepare datasets
# path = osp.join(osp.dirname(osp.realpath(__file__)), '..', 'data',args.dataset)
path = r'C:\Users\27430\Desktop\model_implement\dataset\cvd1.csv'

# dataset = Yandex(root=path, name=args.dataset)
dataset = CustomDataset(csv_file=path)
dataset.materialize()
is_classification = dataset.task_type.is_classification

train_dataset, val_dataset, test_dataset = dataset[:0.8], dataset[0.8:0.9], dataset[0.9:]

# Set up data loaders
train_tensor_frame = train_dataset.tensor_frame
val_tensor_frame = val_dataset.tensor_frame
test_tensor_frame = test_dataset.tensor_frame
train_loader = DataLoader(train_tensor_frame, batch_size=args.batch_size,
                          shuffle=True)
val_loader = DataLoader(val_tensor_frame, batch_size=args.batch_size)
test_loader = DataLoader(test_tensor_frame, batch_size=args.batch_size)

if args.numerical_encoder_type == 'linear':
    numerical_encoder = LinearEncoder()
elif args.numerical_encoder_type == 'linearbucket':
    numerical_encoder = LinearBucketEncoder()
elif args.numerical_encoder_type == 'linearperiodic':
    numerical_encoder = LinearPeriodicEncoder()
else:
    raise ValueError(
        f'Unsupported encoder type: {args.numerical_encoder_type}')

stype_encoder_dict = {
    stype.categorical: EmbeddingEncoder(),
    stype.numerical: numerical_encoder,
}

if is_classification:
    output_channels = dataset.num_classes
else:
    output_channels = 1

if args.model_type == 'fttransformer':
    model = FTTransformer(
        channels=args.channels,
        out_channels=output_channels,
        num_layers=args.num_layers,
        col_stats=dataset.col_stats,
        col_names_dict=train_tensor_frame.col_names_dict,
        stype_encoder_dict=stype_encoder_dict,
    ).to(device)
elif args.model_type == 'resnet':
    model = ResNet(
        channels=args.channels,
        out_channels=output_channels,
        num_layers=args.num_layers,
        col_stats=dataset.col_stats,
        col_names_dict=train_tensor_frame.col_names_dict,
    ).to(device)
else:
    raise ValueError(f'Unsupported model type: {args.model_type}')

model = torch.compile(model, dynamic=True) if args.compile else model
optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr)


def train(epoch: int, model: torch.nn.Module, device: torch.device, optimizer: torch.optim.Optimizer,is_classification: bool) -> float:
    model.train()  # 设置模型为训练模式
    loss_accum = total_count = 0

    for tf in tqdm(train_loader, desc=f'Epoch: {epoch}'):
        tf = tf.to(device)  # 将数据移到设备上
        pred = model(tf)  # 前向传播

        # 计算损失
        if is_classification:
            loss = F.cross_entropy(pred, tf.y)
        else:
            loss = F.mse_loss(pred.view(-1), tf.y.view(-1))

        optimizer.zero_grad()  # 清空梯度
        loss.backward()  # 反向传播
        optimizer.step()  # 更新参数

        loss_accum += float(loss) * len(tf.y)  # 累加损失
        total_count += len(tf.y)  # 累加样本数量

    return loss_accum / total_count  # 返回平均损失


@torch.no_grad()
def test(loader: DataLoader, model: torch.nn.Module, device: torch.device, is_classification: bool) -> float:
    import numpy as np
    from sklearn.metrics import r2_score
    model.eval()  # 设置模型为评估模式
    accum = total_count = 0

    pred_list = []
    y_list = []

    for tf in loader:
        tf = tf.to(device)
        pred = model(tf)  # 前向传播

        pred_list.append(pred.view(-1).cpu().numpy())
        y_list.append(tf.y.view(-1).cpu().numpy())

        if is_classification:
            pred_class = pred.argmax(dim=-1)
            accum += float((tf.y == pred_class).sum())  # 计算准确率
        else:
            accum += float(F.mse_loss(pred.view(-1), tf.y.view(-1), reduction='sum'))  # 计算MSE损失
        total_count += len(tf.y)

    if is_classification:
        accuracy = accum / total_count
        return accuracy
    else:
        rmse = (accum / total_count) ** 0.5
        r2 = r2_score(np.concatenate(y_list), np.concatenate(pred_list))  # 计算R²
        return rmse, r2


if is_classification:
    metric = 'Acc'
    best_val_metric = 0
    best_test_metric = 0
else:
    metric = 'RMSE'
    best_val_metric = float('inf')
    best_test_metric = float('inf')

for epoch in range(1, args.epochs + 1):
    train_loss = train(epoch, model, device, optimizer, is_classification)
    train_metric = test(train_loader, model, device, is_classification)
    val_metric = test(val_loader, model, device, is_classification)
    test_metric = test(test_loader, model, device, is_classification)

    if is_classification and val_metric[0] > best_val_metric:
        best_val_metric = val_metric[0]
        best_test_metric = test_metric[0]
    elif not is_classification and val_metric[0] < best_val_metric:
        best_val_metric = val_metric[0]
        best_test_metric = test_metric[0]

    print(f'Train Loss: {train_loss:.4f}, Train {metric}: {train_metric[0]:.4f}, '
          f'Val {metric}: {val_metric[0]:.4f}, Test {metric}: {test_metric[0]:.4f}',
          f'Val R2: {val_metric[1]:.4f}, Test R2: {test_metric[1]:.4f}')


print(f'Best Val {metric}: {best_val_metric:.4f}, '
      f'Best Test {metric}: {best_test_metric:.4f}')
