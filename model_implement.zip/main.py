from sklearn.model_selection import train_test_split
import pandas as pd
from sklearn.preprocessing import StandardScaler
import torch
import numpy as np
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from config.model_config import MyModelConfig
import optuna
# 设置设备
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
print(device)
# 读取数据
data = pd.read_csv(r'C:\Users\27430\Desktop\model_implement\dataset\cvd1.csv')

x = data.iloc[:500, :-1]
y = data.iloc[:500, -1:]

# 数据集划分为训练集和测试集
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.1, random_state=42)

# 数据归一化处理
scaler_x = StandardScaler()
scaler_y = StandardScaler()

x_train_scaled = scaler_x.fit_transform(x_train)
x_test_scaled = scaler_x.transform(x_test)
y_train_scaled = scaler_y.fit_transform(y_train.values.reshape(-1, 1))
y_test_scaled = scaler_y.transform(y_test.values.reshape(-1, 1))

#将输入输出分别合并
train = pd.concat([pd.DataFrame(x_train_scaled,columns=data.columns[:-1]), pd.DataFrame(y_train_scaled,columns=[data.columns[-1]])], axis=1)
test = pd.concat([pd.DataFrame(x_test_scaled,columns=data.columns[:-1]), pd.DataFrame(y_test_scaled,columns=[data.columns[-1]])], axis=1)
cat_col_names = []
num_col_names = list(data.columns[:-1])
target_col = data.columns[-1]

from pytorch_tabular import TabularModel
from pytorch_tabular.config import (
    DataConfig,
    OptimizerConfig,
    TrainerConfig,
)

data_config = DataConfig(
    target=[
        target_col
    ],  # target should always be a list. Multi-targets are only supported for regression. Multi-Task Classification is not implemented
    continuous_cols=num_col_names,
    categorical_cols=cat_col_names,
)
trainer_config = TrainerConfig(
    auto_lr_find=False,  # Runs the LRFinder to automatically derive a learning rate
    batch_size=24,
    max_epochs=100,
    early_stopping="valid_loss",  # Monitor valid_loss for early stopping
    early_stopping_mode="min",  # Set the mode as min because for val_loss, lower is better
    early_stopping_patience=50,  # No. of epochs of degradation training will wait before terminating
    checkpoints="valid_loss",  # Save best checkpoint monitoring val_loss
    load_best=True,  # After training, load the best checkpoint
)
optimizer_config = OptimizerConfig()



# tabular_model = TabularModel(
#     data_config=data_config,
#     model_config=config.model_config("CategoryEmbeddingModel"),
#     optimizer_config=optimizer_config,
#     trainer_config=trainer_config,
#     verbose=True,
#
# )
# config = MyModelConfig(lr = 3.5e-4)
# tabular_model = TabularModel(
#     data_config=data_config,
#     model_config=config.model_config(model_name="Node"),
#     optimizer_config=optimizer_config,
#     trainer_config=trainer_config,
#     verbose=True,
# )

def objective(trial):
    param = {
        #令lr从5e-3到5e-5
        'lr' : trial.suggest_float('lr', 5e-5, 5e-3, log=True)
    }
    config = MyModelConfig(**param)
    model = TabularModel(
        data_config=data_config,
        model_config=config.model_config(model_name="GatedAdditiveTreeEnsemble"),
        optimizer_config=optimizer_config,
        trainer_config=trainer_config,
        verbose=True,
    )
    model.fit(train=train, validation=test)

    result = model.evaluate(test)

    pred_df = model.predict(test)

    # 将pred_df转化为原始值与真实值计算r2
    y_val_actual = scaler_y.inverse_transform(y_test_scaled.reshape(-1, 1)).flatten()
    y_pred_actual = scaler_y.inverse_transform(pred_df['BTH_prediction'].values.reshape(-1, 1)).flatten()

    mse = mean_squared_error(y_val_actual, y_pred_actual)
    # print(f"MSE: {mse}")
    mae = mean_absolute_error(y_val_actual, y_pred_actual)
    # print(f"MAE: {mae}")
    rmse = np.sqrt(mse)
    # print(f"RMSE: {rmse}")
    r2 = r2_score(y_val_actual, y_pred_actual)
    print(f"R2: {r2}")
    return rmse

study = optuna.create_study(direction='minimize')
study.optimize(objective,n_trials=50)

# tabular_model.fit(train=train, validation=test)
#
# result = tabular_model.evaluate(test)
#
# pred_df = tabular_model.predict(test)
#
# #将pred_df转化为原始值与真实值计算r2
# y_val_actual = scaler_y.inverse_transform(y_test_scaled.reshape(-1, 1)).flatten()
# y_pred_actual = scaler_y.inverse_transform(pred_df['BTH_prediction'].values.reshape(-1, 1)).flatten()
#
# #计算r2,mae,mse,rmse
# mse = mean_squared_error(y_val_actual, y_pred_actual)
# print(f"MSE: {mse}")
# mae = mean_absolute_error(y_val_actual, y_pred_actual)
# print(f"MAE: {mae}")
# rmse = np.sqrt(mse)
# print(f"RMSE: {rmse}")
# r2 = r2_score(y_val_actual, y_pred_actual)
# print(f"R2: {r2}")


