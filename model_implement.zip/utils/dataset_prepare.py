import os.path as osp
import pandas as pd
import torch_frame
# os.chdir('C:/Users/27430/Desktop/model_implement')

# df = pd.read_csv('dataset/cvd1.csv')
# print(df.columns)
class CustomDataset(torch_frame.data.Dataset):
    def __init__(self, csv_file: str):
        # Load the dataset from the provided CSV file
        df = pd.read_csv(csv_file)
        #判断是否存在NAN
        if df.isnull().values.any():
            raise ValueError("The dataset contains missing values")
        else:
            print("The dataset does not contain missing values")

        #把输入部分进行z-score标准化（除最后一列都是输入）
        for col in df.columns[:-1]:
            mean = df[col].mean()
            std = df[col].std()

            if std != 0:
                df[col] = (df[col] - mean) / std
            else:
                df[col] = 0  # 或者其他处理方式，例如保持原值

        #将最后一列进行最大最小归一化
        # df['BTH'] = (df['BTH'] - df['BTH'].min()) / (df['BTH'].max() - df['BTH'].min())

            # df[col] = ((df[col] - df[col].mean()) / df[col].std()).astype('float64')


        # Define the column types
        col_to_stype = {col: torch_frame.numerical for col in df.columns}

        super().__init__(df, col_to_stype, target_col='BTH')
# Usage
if __name__ == "__main__":
    dataset = CustomDataset(csv_file=r'C:\Users\27430\Desktop\model_implement\dataset\cvd1.csv')